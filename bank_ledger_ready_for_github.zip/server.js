
const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

const DB_FILE = path.join(__dirname, 'db.json');

function loadDB(){
  if(!fs.existsSync(DB_FILE)){
    fs.writeFileSync(DB_FILE, JSON.stringify({ admins: [{id: 'admin', username: 'admin', password: 'admin123'}], agents: [], customers: [], loans: [] }, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_FILE));
}
function saveDB(db){ fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }

app.post('/admin/login', (req,res)=>{
  const { username, password } = req.body;
  const db = loadDB();
  const admin = db.admins.find(a=>a.username===username && a.password===password);
  if(!admin) return res.status(400).json({ error: 'Invalid admin credentials' });
  res.json({ success: true, user: { id: admin.id, username: admin.username, role: 'admin' } });
});

app.post('/agent/signup', (req,res)=>{
  const { username, password, name } = req.body;
  const db = loadDB();
  if(db.agents.find(a=>a.username===username)) return res.status(400).json({ error: 'Agent exists' });
  const agent = { id: uuidv4(), username, password, name, approved: false };
  db.agents.push(agent);
  saveDB(db);
  res.json({ success: true, agent });
});

app.post('/agent/login', (req,res)=>{
  const { username, password } = req.body;
  const db = loadDB();
  const agent = db.agents.find(a=>a.username===username && a.password===password && a.approved);
  if(!agent) return res.status(400).json({ error: 'Not approved or invalid credentials' });
  res.json({ success: true, user: { id: agent.id, username: agent.username, role: 'agent', name: agent.name } });
});

app.post('/admin/approve-agent', (req,res)=>{
  const { agentId } = req.body;
  const db = loadDB();
  const agent = db.agents.find(a=>a.id===agentId);
  if(!agent) return res.status(404).json({ error: 'Agent not found' });
  agent.approved = true;
  saveDB(db);
  res.json({ success: true });
});

app.post('/customer/register', (req,res)=>{
  const { name, phone, agentId } = req.body;
  const db = loadDB();
  const accountNumber = 'AC' + Math.floor(100000 + Math.random()*900000);
  const customer = { id: uuidv4(), name, phone, accountNumber, balance: 0, agentId: agentId || null };
  db.customers.push(customer);
  saveDB(db);
  res.json({ success: true, customer });
});

app.get('/customers', (req,res)=>{
  const db = loadDB();
  res.json(db.customers);
});

app.post('/transaction', (req,res)=>{
  const { customerId, amount } = req.body;
  const db = loadDB();
  const cust = db.customers.find(c=>c.id===customerId);
  if(!cust) return res.status(404).json({ error: 'Customer not found' });
  cust.balance = Number(cust.balance) + Number(amount);
  saveDB(db);
  res.json({ success: true, balance: cust.balance });
});

app.post('/loan/apply', (req,res)=>{
  const { customerId, amount, duration, frequency, installment, mode, interest_rate, guarantor } = req.body;
  const db = loadDB();
  const loan = { id: uuidv4(), customerId, amount: Number(amount), duration: Number(duration), frequency, installment: Number(installment), mode, interest_rate: Number(interest_rate||0), guarantor, status: 'pending', created_at: new Date().toISOString() };
  db.loans.push(loan);
  saveDB(db);
  res.json({ success: true, loan });
});

app.post('/admin/loan/:id/approve', (req,res)=>{
  const id = req.params.id;
  const db = loadDB();
  const loan = db.loans.find(l=>l.id===id);
  if(!loan) return res.status(404).json({ error: 'Loan not found' });
  loan.status = 'approved';
  saveDB(db);
  res.json({ success: true });
});
app.post('/admin/loan/:id/reject', (req,res)=>{
  const id = req.params.id;
  const db = loadDB();
  const loan = db.loans.find(l=>l.id===id);
  if(!loan) return res.status(404).json({ error: 'Loan not found' });
  loan.status = 'rejected';
  saveDB(db);
  res.json({ success: true });
});

app.get('/loans', (req,res)=>{
  const db = loadDB();
  res.json(db.loans);
});

app.post('/loan/calculate', (req,res)=>{
  const { amount, installment, mode, interest_rate, duration } = req.body;
  const a = Number(amount);
  if(mode === 'fixed'){
    const periods = Math.ceil(a / Number(installment));
    const total = periods * Number(installment);
    const schedule = [];
    for(let i=1;i<=periods;i++) schedule.push({ period: i, payment: Number(installment) });
    return res.json({ periods, total, schedule });
  } else {
    const rate = Number(interest_rate)/100;
    const totalInterest = a * rate * (Number(duration)/12);
    const total = a + totalInterest;
    const monthly = total / Number(duration);
    const schedule = [];
    for(let i=1;i<=Number(duration);i++) schedule.push({ period: i, payment: Number(monthly.toFixed(2)) });
    return res.json({ periods: Number(duration), total, schedule });
  }
});

app.get('/', (req,res)=> res.sendFile(path.join(__dirname, 'public', 'index.html')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Server running on port', PORT));
